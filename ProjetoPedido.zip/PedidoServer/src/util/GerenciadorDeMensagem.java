package util;

import javax.naming.Context;
import javax.naming.NamingException;

import facade.PedidoFacade;
import facade.PedidoFacadeImpl;
import model.Ingrediente;
import model.Item;
import model.Mesa;
import model.Pastel;
import model.Pedido;

public class GerenciadorDeMensagem {
	private PedidoFacade _pedidoFacadeImpl;

	public GerenciadorDeMensagem(String ip) {
		_pedidoFacadeImpl = (PedidoFacade) doLookup(PedidoFacadeImpl.class, PedidoFacade.class);
	}

	public void GerenciarMensagem(byte[] mensagem) {
		int mesa = mensagem[0];
		int numero = mensagem[1];

		// 03#12#0405#0203##
		Pedido pedido = new Pedido(new Pastel(numero), new Mesa(mesa));

		if (mensagem[2] == '#') {
			int i = 3;
			int idIngrediente;
			while (mensagem[i] != '#') {
				idIngrediente = mensagem[i];
				pedido.adicionarIngredienteExcluido(new Ingrediente(idIngrediente));
				i++;
			}
			i++;
			while (mensagem[i] != '#') {
				idIngrediente = mensagem[i];
				pedido.adicionarIngredienteIncluso(new Ingrediente(idIngrediente));
				i++;
			}
		}

		_pedidoFacadeImpl.adiciona(pedido);
	}

	private <T, P> Object doLookup(Class<T> bean, Class<P> interfac) {
		Object object = null;
		Context context = null;
		String lookupName;

		lookupName = Lookup.getLookupName(bean, interfac);
		Log.logarSaida(lookupName);
		try {
			context = ClientUtility.getInitialContext();
			return context.lookup(lookupName);
		} catch (NamingException e) {
			for (StackTraceElement stackTraceElement : e.getStackTrace()) {
				Log.logarErro(stackTraceElement.toString());
			}
			e.printStackTrace();
		}

		return object;
	}

}
