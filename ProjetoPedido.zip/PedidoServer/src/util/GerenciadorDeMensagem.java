package util;

import javax.naming.Context;
import javax.naming.NamingException;

import facade.ItemFacade;
import facade.ItemFacadeImpl;
import facade.PedidoFacade;
import facade.PedidoFacadeImpl;
import model.Bebida;
import model.Ingrediente;
import model.Item;
import model.Mesa;
import model.Pastel;
import model.Pedido;

public class GerenciadorDeMensagem {
	private PedidoFacade _pedidoFacadeImpl;
	private ItemFacade _itemFacadeImpl;

	public GerenciadorDeMensagem(String ip) {
		_pedidoFacadeImpl = (PedidoFacade) doLookup(PedidoFacadeImpl.class, PedidoFacade.class);
		_itemFacadeImpl = (ItemFacade) doLookup(ItemFacadeImpl.class, ItemFacade.class);
	}

	public void GerenciarMensagem(byte[] mensagem) {
		int mesa = mensagem[0];
		int numero = mensagem[1];

		Item item = _itemFacadeImpl.recupera(numero);

		// 03#12#0405#0203##
		Pedido pedido = new Pedido(item, new Mesa(mesa));

		if (item instanceof Pastel) {
			if (mensagem[2] == '#') {
				int i = 3;
				int idIngrediente;
				while (mensagem[i] != '#') {
					idIngrediente = mensagem[i];
					pedido.adicionarIngredienteExcluido(new Ingrediente(idIngrediente));
					i++;
				}
				i++;
				while (mensagem[i] != '#') {
					idIngrediente = mensagem[i];
					pedido.adicionarIngredienteIncluso(new Ingrediente(idIngrediente));
					i++;
				}
			}
		}

		_pedidoFacadeImpl.adiciona(pedido);
	}

	private <T, P> Object doLookup(Class<T> bean, Class<P> interfac) {
		Object object = null;
		Context context = null;
		String lookupName;

		lookupName = Lookup.getLookupName(bean, interfac);
		Log.logarSaida(lookupName);
		try {
			context = ClientUtility.getInitialContext();
			return context.lookup(lookupName);
		} catch (NamingException e) {
			for (StackTraceElement stackTraceElement : e.getStackTrace()) {
				Log.logarErro(stackTraceElement.toString());
			}
			e.printStackTrace();
		}

		return object;
	}

}
