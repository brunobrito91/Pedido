package main;

import util.GerenciadorDeMensagem;

public class Principal {

	public static void main(String[] args) {
//		Servidor servidor = new Servidor(9876);
//		servidor.IniciarServidor();

		GerenciadorDeMensagem gm = new GerenciadorDeMensagem(null);
		//3,12,#,4,5,#,2,3,#
		byte[] mensagem = new byte[9];
		mensagem[0] = 4;
		mensagem[1] = 1;
		mensagem[2] = '#';
		mensagem[3] = 3;
		mensagem[4] = 4;
		mensagem[5] = '#';
		mensagem[6] = 1;
		mensagem[7] = 4;
		mensagem[8] = '#';
		
		gm.GerenciarMensagem(mensagem);
	}

}
