package main;

import comunicacao.Servidor;
import util.GerenciadorDeMensagem;

public class Principal {

	public static void main(String[] args) {
		 Servidor servidor = new Servidor(9876);
		 servidor.IniciarServidor();

//		GerenciadorDeMensagem gm = new GerenciadorDeMensagem(null);
//		// 3,12,#,4,5,#,2,3,#
//		byte[] mensagem = new byte[9];
//		mensagem[0] = 4;
//		mensagem[1] = 10;
//		mensagem[2] = '#';
//		mensagem[3] = 0;
////		mensagem[4] = 5;
//		mensagem[4] = '#';
//		mensagem[5] = 0;
////		mensagem[7] = 3;
//		mensagem[6] = '#';
//
//		gm.GerenciarMensagem(mensagem);
	}

}
