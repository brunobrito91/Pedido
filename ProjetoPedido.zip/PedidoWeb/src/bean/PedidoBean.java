package bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.hibernate.validator.HibernateValidator;

import facade.PedidoFacade;
import facade.PedidoFacadeImpl;
import model.Bebida;
import model.Ingrediente;
import model.Pastel;
import model.Pedido;
import util.Lookup;

@ManagedBean
@ViewScoped
public class PedidoBean {
	private PedidoFacade pedidoFacade;

	private List<Pedido> pedidos;
	private List<Pedido> pedidosBar;
	private List<Pedido> pedidosCozinha;

	public PedidoBean() {
		System.out.println("PedidoBean");
		pedidoFacade = (PedidoFacade) Lookup.doLookup(PedidoFacadeImpl.class, PedidoFacade.class);
		pedidos = pedidoFacade.recuperaTodos();

		pedidosBar = new ArrayList<Pedido>();
		pedidosCozinha = new ArrayList<Pedido>();

		for (Pedido pedido : pedidos) {

			if (pedido.getItem() instanceof Pastel) {
				pedidosCozinha.add(pedido);
			} else if (pedido.getItem() instanceof Bebida) {
				pedidosBar.add(pedido);
			}
		}
	}

	public List<Pedido> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}

	public List<Pedido> getPedidosBar() {
		return pedidosBar;
	}

	public void setPedidosBar(List<Pedido> pedidosBar) {
		this.pedidosBar = pedidosBar;
	}

	public List<Pedido> getPedidosCozinha() {
		return pedidosCozinha;
	}

	public void setPedidosCozinha(List<Pedido> pedidosCozinha) {
		this.pedidosCozinha = pedidosCozinha;
	}

	public void finalizar() {

	}

}
