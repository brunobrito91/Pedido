package bean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import facade.PedidoFacade;
import facade.PedidoFacadeImpl;
import model.Pedido;
import util.Lookup;

@ManagedBean
@ViewScoped
public class PedidoBean {
	private PedidoFacade pedidoFacade;
	private List<Pedido> pedidos;

	public PedidoBean() {
		System.out.println("PedidoBean");
		pedidoFacade = (PedidoFacade) Lookup.doLookup(PedidoFacadeImpl.class, PedidoFacade.class);
		pedidos = pedidoFacade.recuperaTodos();
		System.out.println(pedidos.size());
	}

	public List<Pedido> getPedidos() {
		System.out.println("getPedidos");
		return pedidos;
	}

	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}

}
