package bean;

import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import facade.PedidoFacade;
import facade.PedidoFacadeImpl;
import model.Pedido;
import util.Lookup;

@ManagedBean
@RequestScoped
public class PedidoBean {
	private PedidoFacade pedidoFacade;

	private Set<Pedido> pedidos;
	private Set<Pedido> pedidosBar;
	private Set<Pedido> pedidosCozinha;

	public PedidoBean() {
		System.out.println("PedidoBean");
		pedidoFacade = (PedidoFacade) Lookup.doLookup(PedidoFacadeImpl.class, PedidoFacade.class);
		// pedidos = pedidoFacade.recuperaTodos();
		//
		// pedidosBar = new HashSet<Pedido>();
		// pedidosCozinha = new HashSet<Pedido>();

		pedidosBar = pedidoFacade.recuperaPedidosBar();
		pedidosCozinha = pedidoFacade.recuperaPedidosCozinha();

		// for (Pedido pedido : pedidos) {
		// if (pedido.getItem() instanceof Pastel) {
		// pedidosCozinha.add(pedido);
		// } else if (pedido.getItem() instanceof Bebida) {
		// pedidosBar.add(pedido);
		// }
		// }
	}

	public Set<Pedido> getPedidos() {
		return pedidos;
	}

	public void setPedidos(Set<Pedido> pedidos) {
		this.pedidos = pedidos;
	}

	public Set<Pedido> getPedidosBar() {
		return pedidosBar;
	}

	public void setPedidosBar(Set<Pedido> pedidosBar) {
		this.pedidosBar = pedidosBar;
	}

	public Set<Pedido> getPedidosCozinha() {
		return pedidosCozinha;
	}

	public void setPedidosCozinha(Set<Pedido> pedidosCozinha) {
		this.pedidosCozinha = pedidosCozinha;
	}

	public void finalizar() {

	}

}
