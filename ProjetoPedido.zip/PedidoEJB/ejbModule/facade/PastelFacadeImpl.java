package facade;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.PastelDAO;
import model.Pastel;

@Stateless
public class PastelFacadeImpl implements PastelFacade {

	@EJB
	private PastelDAO pastelDao;

	@Override
	public void adiciona(Pastel pastel) {
		pastelDao.adiciona(pastel);
	}

	@Override
	public Pastel atualiza(Pastel pastel) {
		return pastelDao.atualiza(pastel);
	}

	@Override
	public void deleta(Pastel pastel) {
		pastelDao.deleta(pastel.getId(), Pastel.class);
	}

	@Override
	public Pastel recupera(int entityID) {
		return pastelDao.recupera(entityID);
	}

	@Override
	public List<Pastel> recuperaTodos() {
		return pastelDao.recuperaTodos();
	}

}
