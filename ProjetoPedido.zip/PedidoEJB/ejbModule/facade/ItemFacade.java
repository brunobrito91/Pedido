package facade;

import java.util.Set;

import javax.ejb.Remote;

import model.Item;

@Remote
public interface ItemFacade {

	public abstract void adiciona(Item item);

	public abstract Item atualiza(Item item);

	public abstract void deleta(Item item);

	public abstract Item recupera(int entityID);

	public abstract Set<Item> recuperaTodos();

}