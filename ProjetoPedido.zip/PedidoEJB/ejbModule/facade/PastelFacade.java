package facade;

import java.util.List;

import javax.ejb.Remote;

import model.Pastel;

@Remote
public interface PastelFacade {

	public abstract void adiciona(Pastel pastel);

	public abstract Pastel atualiza(Pastel pastel);

	public abstract void deleta(Pastel pastel);

	public abstract Pastel recupera(int entityID);

	public abstract List<Pastel> recuperaTodos();

}