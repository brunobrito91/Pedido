package facade;

import java.util.Set;

import javax.ejb.Remote;

import model.Ingrediente;

@Remote
public interface IngredienteFacade {

	public abstract void adiciona(Ingrediente ingrediente);

	public abstract Ingrediente atualiza(Ingrediente ingrediente);

	public abstract void deleta(Ingrediente ingrediente);

	public abstract Ingrediente recupera(int entityID);

	public abstract Set<Ingrediente> recuperaTodos();

}