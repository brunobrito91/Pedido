package facade;

import java.util.Set;

import javax.ejb.Remote;

import model.Mesa;

@Remote
public interface MesaFacade {

	public abstract void adiciona(Mesa mesa);

	public abstract Mesa atualiza(Mesa mesa);

	public abstract void deleta(Mesa mesa);

	public abstract Mesa recupera(int entityID);

	public abstract Set<Mesa> recuperaTodos();

}