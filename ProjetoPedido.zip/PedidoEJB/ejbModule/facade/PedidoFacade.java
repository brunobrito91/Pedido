package facade;

import java.util.Set;

import javax.ejb.Remote;

import model.Pedido;

@Remote
public interface PedidoFacade {

	public abstract void adiciona(Pedido pedido);

	public abstract Pedido atualiza(Pedido pedido);

	public abstract void deleta(Pedido pedido);

	public abstract Pedido recupera(int entityID);

	public abstract Set<Pedido> recuperaTodos();

	public abstract Set<Pedido> recuperaPedidosBar();

	public abstract Set<Pedido> recuperaPedidosCozinha();

}