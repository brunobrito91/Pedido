package facade;

import java.util.List;

import javax.ejb.Remote;

import model.Ingrediente;
import model.Pedido;

@Remote
public interface PedidoFacade {

	public abstract void adiciona(Pedido pedido);

	public abstract Pedido atualiza(Pedido pedido);

	public abstract void deleta(Pedido pedido);

	public abstract Pedido recupera(int entityID);

	public abstract List<Pedido> recuperaTodos();

	public abstract List<Ingrediente> recuperarIngredientesExcluidos(int itemId);

	public abstract List<Ingrediente> recuperarIngredientesInclusos(int itemId);

}