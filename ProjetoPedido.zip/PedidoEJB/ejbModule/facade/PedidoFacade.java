package facade;

import java.util.List;

import javax.ejb.Remote;

import model.Pedido;

@Remote
public interface PedidoFacade {

	public abstract void adiciona(Pedido pedido);

	public abstract Pedido atualiza(Pedido pedido);

	public abstract void deleta(Pedido pedido);

	public abstract Pedido recupera(int entityID);

	public abstract List<Pedido> recuperaTodos();

}