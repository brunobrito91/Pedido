package facade;

import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.MesaDAO;
import model.Mesa;

@Stateless
public class MesaFacadeImpl implements MesaFacade {

	@EJB
	private MesaDAO mesaDao;

	@Override
	public void adiciona(Mesa mesa) {
		mesaDao.adiciona(mesa);
	}

	@Override
	public Mesa atualiza(Mesa mesa) {
		return mesaDao.atualiza(mesa);
	}

	@Override
	public void deleta(Mesa mesa) {
		mesaDao.deleta(mesa.getId(), Mesa.class);
	}

	@Override
	public Mesa recupera(int entityID) {
		return mesaDao.recupera(entityID);
	}

	@Override
	public Set<Mesa> recuperaTodos() {
		return mesaDao.recuperaTodos();
	}

}
