package facade;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.PedidoDAO;
import model.Pedido;

@Stateless
public class PedidoFacadeImpl implements PedidoFacade {

	@EJB
	private PedidoDAO pedidoDao;

	@Override
	public void adiciona(Pedido pedido) {
		pedidoDao.adiciona(pedido);
	}

	@Override
	public Pedido atualiza(Pedido pedido) {
		return pedidoDao.atualiza(pedido);
	}

	@Override
	public void deleta(Pedido pedido) {
		pedidoDao.deleta(pedido.getId(), Pedido.class);
	}

	@Override
	public Pedido recupera(int entityID) {
		return pedidoDao.recupera(entityID);
	}

	@Override
	public List<Pedido> recuperaTodos() {
		return pedidoDao.recuperaTodos();
	}

}
