package facade;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.ItemDAO;
import model.Item;

@Stateless
public class ItemFacadeImpl implements ItemFacade {

	@EJB
	private ItemDAO itemDao;

	@Override
	public void adiciona(Item item) {
		itemDao.adiciona(item);
	}

	@Override
	public Item atualiza(Item item) {
		return itemDao.atualiza(item);
	}

	@Override
	public void deleta(Item item) {
		itemDao.deleta(item.getId(), Item.class);
	}

	@Override
	public Item recupera(int entityID) {
		return itemDao.recupera(entityID);
	}

	@Override
	public List<Item> recuperaTodos() {
		return itemDao.recuperaTodos();
	}

}
