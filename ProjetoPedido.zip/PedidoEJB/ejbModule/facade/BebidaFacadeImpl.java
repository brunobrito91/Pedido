package facade;

import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.BebidaDAO;
import model.Bebida;

@Stateless
public class BebidaFacadeImpl implements BebidaFacade {

	@EJB
	private BebidaDAO bebidaDao;

	@Override
	public void adiciona(Bebida bebida) {
		bebidaDao.adiciona(bebida);
	}

	@Override
	public Bebida atualiza(Bebida bebida) {
		return bebidaDao.atualiza(bebida);
	}

	@Override
	public void deleta(Bebida bebida) {
		bebidaDao.deleta(bebida.getId(), Bebida.class);
	}

	@Override
	public Bebida recupera(int entityID) {
		return bebidaDao.recupera(entityID);
	}

	@Override
	public Set<Bebida> recuperaTodos() {
		return bebidaDao.recuperaTodos();
	}

}
