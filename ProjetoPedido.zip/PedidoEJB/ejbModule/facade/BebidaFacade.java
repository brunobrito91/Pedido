package facade;

import java.util.Set;

import javax.ejb.Remote;

import model.Bebida;

@Remote
public interface BebidaFacade {

	public abstract void adiciona(Bebida bebida);

	public abstract Bebida atualiza(Bebida bebida);

	public abstract void deleta(Bebida bebida);

	public abstract Bebida recupera(int entityID);

	public abstract Set<Bebida> recuperaTodos();

}