package facade;

import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.IngredienteDAO;
import model.Ingrediente;

@Stateless
public class IngredienteFacadeImpl implements IngredienteFacade {

	@EJB
	private IngredienteDAO ingredienteDao;

	@Override
	public void adiciona(Ingrediente ingrediente) {
		ingredienteDao.adiciona(ingrediente);
	}

	@Override
	public Ingrediente atualiza(Ingrediente ingrediente) {
		return ingredienteDao.atualiza(ingrediente);
	}

	@Override
	public void deleta(Ingrediente ingrediente) {
		ingredienteDao.deleta(ingrediente.getId(), Ingrediente.class);
	}

	@Override
	public Ingrediente recupera(int entityID) {
		return ingredienteDao.recupera(entityID);
	}

	@Override
	public Set<Ingrediente> recuperaTodos() {
		return ingredienteDao.recuperaTodos();
	}

}
