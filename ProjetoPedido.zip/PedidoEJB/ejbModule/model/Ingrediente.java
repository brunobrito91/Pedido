package model;

import javax.persistence.Entity;

@Entity
public class Ingrediente extends Item {
	private static final long serialVersionUID = -9041123283624951834L;

	public Ingrediente() {
		super();
	}

	public Ingrediente(int id) {
		super(id);
	}

}
