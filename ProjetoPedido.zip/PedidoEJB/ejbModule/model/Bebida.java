package model;

import javax.persistence.Entity;

@Entity
public class Bebida extends Item {
	private static final long serialVersionUID = -2189808938202471505L;

	public Bebida() {
		super();
	}

	public Bebida(int id) {
		super(id);
	}

}
