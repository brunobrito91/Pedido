package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

@Entity
public class Pastel extends Item {
	private static final long serialVersionUID = -7050395306164906751L;

	@ManyToMany
	@JoinTable(name = "pastel_ingredientes", joinColumns = @JoinColumn(name = "id_pastel"), inverseJoinColumns = @JoinColumn(name = "id_ingrediente"))
	private Set<Ingrediente> ingredientes;

	public Pastel() {
		super();
		ingredientes = new HashSet<Ingrediente>();
	}

	public Pastel(int id) {
		super(id);
	}

	public Set<Ingrediente> getIngredientes() {
		return ingredientes;
	}

	public void setIngredientes(Set<Ingrediente> ingredientes) {
		this.ingredientes = ingredientes;
	}

}
