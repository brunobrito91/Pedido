package model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;

@Entity
public class Pastel extends Item {
	private static final long serialVersionUID = -7050395306164906751L;

	@ElementCollection
	private List<Ingrediente> ingredientes;

	public Pastel() {
		super();
		ingredientes = new ArrayList<Ingrediente>();
	}

	public Pastel(int id) {
		super(id);
	}

	public List<Ingrediente> getIngredientes() {
		return ingredientes;
	}

	public void setIngredientes(List<Ingrediente> ingredientes) {
		this.ingredientes = ingredientes;
	}

}
