package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Pedido implements Serializable {

	private static final long serialVersionUID = 2137968939909476782L;

	@Id
	@GeneratedValue
	private int id;

	private Pastel pastel;

	@OneToOne
	private Mesa mesa;

	@ElementCollection
	@CollectionTable(name = "ingredientesExcluidos")
	private List<Ingrediente> ingredientesExcluidos;

	@ElementCollection
	@CollectionTable(name = "ingredientesInclusos")
	private List<Ingrediente> ingredientesInclusos;

	private Date data;

	public Pedido(Pastel pastel, Mesa mesa) {
		this.pastel = pastel;
		this.mesa = mesa;
		this.data = new Date();
		ingredientesExcluidos = new ArrayList<Ingrediente>();
		ingredientesInclusos = new ArrayList<Ingrediente>();
	}

	public Pedido() {
		this.data = new Date();
		ingredientesExcluidos = new ArrayList<Ingrediente>();
		ingredientesInclusos = new ArrayList<Ingrediente>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Pastel getPastel() {
		return pastel;
	}

	public void setPastel(Pastel pastel) {
		this.pastel = pastel;
	}

	public Mesa getMesa() {
		return mesa;
	}

	public void setMesa(Mesa mesa) {
		this.mesa = mesa;
	}

	public List<Ingrediente> getIngredientesExcluidos() {
		return ingredientesExcluidos;
	}

	public void setIngredientesExcluidos(List<Ingrediente> ingredientesExcluidos) {
		this.ingredientesExcluidos = ingredientesExcluidos;
	}

	public List<Ingrediente> getIngredientesInclusos() {
		return ingredientesInclusos;
	}

	public void setIngredientesInclusos(List<Ingrediente> ingredientesInclusos) {
		this.ingredientesInclusos = ingredientesInclusos;
	}

	public Date getData() {
		return data;
	}

	public String getHora() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", new Locale("pt", "br"));
		return sdf.format(data);
	}

	public void setData(Date data) {
		this.data = data;
	}

	public void adicionarIngredienteExcluido(Ingrediente numeroIngrediente) {
		ingredientesExcluidos.add(numeroIngrediente);
	}

	public void adicionarIngredienteIncluso(Ingrediente numeroIngrediente) {
		ingredientesInclusos.add(numeroIngrediente);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pedido other = (Pedido) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Pedido [id=" + id + ", pastel=" + pastel + ", mesa=" + mesa + ", ingredientesExcluidos="
				+ ingredientesExcluidos + ", ingredientesInclusos=" + ingredientesInclusos + ", data=" + data + "]";
	}

}
