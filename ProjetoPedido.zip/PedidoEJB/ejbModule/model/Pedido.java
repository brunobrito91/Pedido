package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.persistence.CollectionTable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Pedido implements Serializable {

	private static final long serialVersionUID = 2137968939909476782L;

	@Id
	@GeneratedValue
	private int id;

	@ManyToOne
	private Item item;

	@ManyToOne
	private Mesa mesa;

	@ManyToMany
	@CollectionTable(name = "ingredientesExcluidos")
	private List<Ingrediente> ingredientesExcluidos;

	@ManyToMany
	@CollectionTable(name = "ingredientesIncluidos")
	private List<Ingrediente> ingredientesIncluidos;

	private Date data;

	private boolean finalizado;

	public Pedido(Item item, Mesa mesa) {
		this.item = item;
		this.mesa = mesa;
		this.data = new Date();
		ingredientesExcluidos = new ArrayList<Ingrediente>();
		ingredientesIncluidos = new ArrayList<Ingrediente>();
	}

	public Pedido() {
		this.data = new Date();
		ingredientesExcluidos = new ArrayList<Ingrediente>();
		ingredientesIncluidos = new ArrayList<Ingrediente>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Mesa getMesa() {
		return mesa;
	}

	public void setMesa(Mesa mesa) {
		this.mesa = mesa;
	}

	public List<Ingrediente> getIngredientesExcluidos() {
		return ingredientesExcluidos;
	}

	public void setIngredientesExcluidos(List<Ingrediente> ingredientesExcluidos) {
		this.ingredientesExcluidos = ingredientesExcluidos;
	}

	public List<Ingrediente> getIngredientesInclusos() {
		return ingredientesIncluidos;
	}

	public void setIngredientesInclusos(List<Ingrediente> ingredientesInclusos) {
		this.ingredientesIncluidos = ingredientesInclusos;
	}

	public Date getData() {
		return data;
	}

	public String getHora() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", new Locale("pt", "br"));
		return sdf.format(data);
	}

	public void setData(Date data) {
		this.data = data;
	}

	public void adicionarIngredienteExcluido(Ingrediente numeroIngrediente) {
		ingredientesExcluidos.add(numeroIngrediente);
	}

	public void adicionarIngredienteIncluso(Ingrediente numeroIngrediente) {
		ingredientesIncluidos.add(numeroIngrediente);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pedido other = (Pedido) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Pedido [id=" + id + ", item=" + item + ", mesa=" + mesa + ", ingredientesExcluidos="
				+ ingredientesExcluidos + ", ingredientesInclusos=" + ingredientesIncluidos + ", data=" + data + "]";
	}

	public void setFinalizado(boolean finalizado) {
		this.finalizado = finalizado;
	}

	public boolean getFinalizado() {
		return finalizado;
	}

}
