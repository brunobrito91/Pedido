package dao;

import javax.ejb.Stateless;

import model.Item;

@Stateless
public class ItemDAO extends GenericDAOImpl<Item> {
	public ItemDAO() {
		super(Item.class);
	}
}
