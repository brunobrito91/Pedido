package dao;

import java.util.HashSet;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Fetch;
import javax.persistence.criteria.Root;

import model.Ingrediente;
import model.Pedido;

@Stateless
public class PedidoDAO extends GenericDAOImpl<Pedido> {
	public PedidoDAO() {
		super(Pedido.class);
	}

	public Set<Pedido> recuperaTodos() {
		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
		CriteriaQuery<Pedido> q = criteriaBuilder.createQuery(Pedido.class);
		Root<Pedido> c = q.from(Pedido.class);
		Fetch<Pedido, Set<Ingrediente>> p = c.fetch("ingredientesExcluidos");
		q.select(c);

		return new HashSet<Pedido>(em.createQuery(q).getResultList());
	}

	public Set<Pedido> recuperaPedidosBar() {
		TypedQuery<Pedido> query = em.createQuery("SELECT p FROM Pedido p JOIN p.item i, Bebida b WHERE i.id = b.id",
				Pedido.class);

		return new HashSet<Pedido>(query.getResultList());
	}

	public Set<Pedido> recuperaPedidosCozinha() {
		TypedQuery<Pedido> query = em.createQuery(
				"SELECT p FROM Pedido p JOIN FETCH p.ingredientesExcluidos JOIN p.item i, Pastel b WHERE i.id = b.id ",
				Pedido.class);

		return new HashSet<Pedido>(query.getResultList());
	}

}
