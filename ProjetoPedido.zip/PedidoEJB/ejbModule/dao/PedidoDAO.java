package dao;

import javax.ejb.Stateless;
import model.Pedido;

@Stateless
public class PedidoDAO extends GenericDAOImpl<Pedido> {
	public PedidoDAO() {
		super(Pedido.class);
	}
}
