package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import model.Ingrediente;
import model.Pedido;

@Stateless
public class PedidoDAO extends GenericDAOImpl<Pedido> {
	public PedidoDAO() {
		super(Pedido.class);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Ingrediente> recuperarIngredientesExcluidos(int pedidoId) {
		TypedQuery<Ingrediente> query = em
				.createQuery("SELECT * FROM pedido.ingredientesexcluidos where Pedido_id = :id", Ingrediente.class);

		query.setParameter("id", pedidoId);

		return query.getResultList();
	}

	public List<Ingrediente> recuperarIngredientesInclusos(int pedidoId) {
		TypedQuery<Ingrediente> query = em
				.createQuery("SELECT * FROM pedido.ingredientesincluidos where Pedido_id = :id", Ingrediente.class);

		query.setParameter("id", pedidoId);

		return query.getResultList();
	}
}
