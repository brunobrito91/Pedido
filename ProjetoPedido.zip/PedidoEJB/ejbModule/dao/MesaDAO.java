package dao;

import javax.ejb.Stateless;

import model.Mesa;

@Stateless
public class MesaDAO extends GenericDAOImpl<Mesa> {
	public MesaDAO() {
		super(Mesa.class);
	}
}
