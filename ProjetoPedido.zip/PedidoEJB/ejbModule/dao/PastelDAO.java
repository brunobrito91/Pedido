package dao;

import javax.ejb.Stateless;

import model.Pastel;

@Stateless
public class PastelDAO extends GenericDAOImpl<Pastel> {
	public PastelDAO() {
		super(Pastel.class);
	}
}
