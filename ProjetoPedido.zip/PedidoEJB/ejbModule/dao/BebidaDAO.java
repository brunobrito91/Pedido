package dao;

import javax.ejb.Stateless;

import model.Bebida;

@Stateless
public class BebidaDAO extends GenericDAOImpl<Bebida> {
	public BebidaDAO() {
		super(Bebida.class);
	}
}
