package dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public abstract class GenericDAOImpl<T> implements GenericDAO<T> {
	private final static String UNIT_NAME = "PedidoPU";

	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	private Class<T> entityClass;

	public GenericDAOImpl(Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	public void adiciona(T entity) {
		em.persist(entity);
	}

	public void deleta(Object id, Class<T> classe) {
		T entityToBeRemoved = em.getReference(classe, id);

		em.remove(entityToBeRemoved);
	}

	public T atualiza(T entity) {
		return em.merge(entity);
	}

	public T recupera(Object entityID) throws RuntimeException {
		T t = null;
		try {
			t = em.find(entityClass, entityID);
		} catch (RuntimeException e) {
			throw e;
		}
		return t;
	}

	// Using the unchecked because JPA does not have a
	// em.getCriteriaBuilder().createQuery()<T> method
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<T> recuperaTodos() {
		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
		CriteriaQuery cq = criteriaBuilder.createQuery();
		Root<T> select = cq.from(entityClass);
		cq.select(select);

		return em.createQuery(cq).getResultList();
	}

}
