package dao;

import javax.ejb.Stateless;

import model.Ingrediente;

@Stateless
public class IngredienteDAO extends GenericDAOImpl<Ingrediente> {
	public IngredienteDAO() {
		super(Ingrediente.class);
	}
}
