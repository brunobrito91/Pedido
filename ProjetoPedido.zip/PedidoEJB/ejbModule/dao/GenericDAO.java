package dao;

import java.util.List;

public interface GenericDAO<T> {
	void adiciona(T entity);

	void deleta(Object id, Class<T> classe);

	T atualiza(T entity);

	T recupera(Object entityID);

	List<T> recuperaTodos();

}
