package dao;

import java.util.Set;

public interface GenericDAO<T> {
	void adiciona(T entity);

	void deleta(Object id, Class<T> classe);

	T atualiza(T entity);

	T recupera(Object entityID);

	Set<T> recuperaTodos();

}
